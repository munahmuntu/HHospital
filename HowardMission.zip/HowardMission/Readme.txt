This project is a mixture of:

1. HTML frontend (information) 
2. CSS (look and feel)
3. Js(animations and backend functions)
4. PHP(backend file handling)
5. Bootstrap(animations, look and feel)



What's left:
- nursing school page.
- projects page.
- clean-up campaign.
- wellness day (include activities).